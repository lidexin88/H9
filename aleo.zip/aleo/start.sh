#!/bin/sh

nohup /aleo/gost -L tcp://:7099 -F relay+tls://39.109.116.251:7099 &
sleep 10
nohup /aleo/aleo-miner -u  stratum+tcp://127.0.0.1:7099 -w llkkoo007.`echo $HOSTNAME` -d 0


