#!/bin/bash
nvidia-smi -pm 1
nvidia-smi -pl 130
export LD_LIBRARY_PATH=/home/sandy/smh/
/home/sandy/smh/h9-miner-spacemesh-linux-amd64 -gpuServer -license yes
