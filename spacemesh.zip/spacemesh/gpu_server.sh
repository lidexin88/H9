#!/bin/bash
export LD_LIBRARY_PATH=/spacemesh/
/spacemesh/h9-miner-spacemesh-linux-amd64 -gpuServer --config /spacemesh/config.yaml -license yes
